
<?php

$host = "localhost";
$username = "root";
$password = "";
$db_name = "db_sman1_lasem";

$conn = mysqli_connect($host, $username, $password, $db_name);

// if ($conn)
// echo "Connection Success.....!";
// else
// echo "Connection Failed.....!";

?>